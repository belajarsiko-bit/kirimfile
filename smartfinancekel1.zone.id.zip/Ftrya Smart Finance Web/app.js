// app.js - Smart Finance Global Functions

// ============================================
// LOCAL STORAGE HELPER
// ============================================
const storage = {
    get: (key) => {
        const data = localStorage.getItem(key);
        return data ? JSON.parse(data) : null;
    },
    set: (key, value) => {
        localStorage.setItem(key, JSON.stringify(value));
    },
    remove: (key) => {
        localStorage.removeItem(key);
    }
};

// ============================================
// INITIALIZE DATA
// ============================================
let transactions = storage.get('transactions') || [];
let budgets = storage.get('budgets') || [];
let categories = storage.get('categories') || ['Gaji', 'Makan', 'Dapur', 'Jajan', 'Transportasi'];
let profile = storage.get('profile') || {
    name: 'Nama Pengguna',
    email: 'email@example.com',
    photo: '',
    monthlyIncome: 0,
    motto: 'Hemat pangkal kaya'
};

// ============================================
// UTILITY FUNCTIONS
// ============================================

// Format currency to Indonesian Rupiah
const formatCurrency = (amount) => {
    return new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    }).format(amount);
};

// Get transactions by date range
const getTransactionsByDateRange = (start, end) => {
    return transactions.filter(t => {
        const date = new Date(t.date);
        return date >= start && date <= end;
    });
};

// Calculate totals (income, expense, balance)
const calculateTotals = (transactionList) => {
    const income = transactionList
        .filter(t => t.type === 'income')
        .reduce((sum, t) => sum + t.amount, 0);
    const expense = transactionList
        .filter(t => t.type === 'expense')
        .reduce((sum, t) => sum + t.amount, 0);
    return { 
        income, 
        expense, 
        balance: income - expense 
    };
};

// Get expense by category
const getExpenseByCategory = (transactionList) => {
    const expensesByCategory = {};
    transactionList
        .filter(t => t.type === 'expense')
        .forEach(t => {
            expensesByCategory[t.category] = (expensesByCategory[t.category] || 0) + t.amount;
        });
    return expensesByCategory;
};

// Sort transactions by date (newest first)
const sortTransactionsByDate = (transactionList) => {
    return [...transactionList].sort((a, b) => new Date(b.date) - new Date(a.date));
};

// ============================================
// TRANSACTION FUNCTIONS
// ============================================

// Add new transaction
const addTransaction = (transaction) => {
    transactions.push({
        id: Date.now(),
        ...transaction
    });
    storage.set('transactions', transactions);
    return true;
};

// Delete transaction
const deleteTransaction = (id) => {
    transactions = transactions.filter(t => t.id !== id);
    storage.set('transactions', transactions);
    return true;
};

// Get transaction by ID
const getTransactionById = (id) => {
    return transactions.find(t => t.id === id);
};

// ============================================
// CATEGORY FUNCTIONS
// ============================================

// Add new category
const addCategory = (categoryName) => {
    if (!categories.includes(categoryName)) {
        categories.push(categoryName);
        storage.set('categories', categories);
        return true;
    }
    return false;
};

// Get all categories
const getCategories = () => {
    return categories;
};

// ============================================
// BUDGET FUNCTIONS
// ============================================

// Add or update budget
const setBudget = (budget) => {
    const existingIndex = budgets.findIndex(b => b.category === budget.category);
    
    if (existingIndex !== -1) {
        budgets[existingIndex] = {
            id: budgets[existingIndex].id,
            ...budget
        };
    } else {
        budgets.push({
            id: Date.now(),
            ...budget
        });
    }
    
    storage.set('budgets', budgets);
    return true;
};

// Delete budget
const deleteBudget = (id) => {
    budgets = budgets.filter(b => b.id !== id);
    storage.set('budgets', budgets);
    return true;
};

// Get budget by category
const getBudgetByCategory = (category) => {
    return budgets.find(b => b.category === category);
};

// Check if budget is near limit (80% or more)
const isBudgetNearLimit = (budget, spent) => {
    return (spent / budget.amount) >= 0.8;
};

// ============================================
// PROFILE FUNCTIONS
// ============================================

// Update profile
const updateProfile = (newProfile) => {
    profile = { ...profile, ...newProfile };
    storage.set('profile', profile);
    return true;
};

// Get profile
const getProfile = () => {
    return profile;
};

// ============================================
// DATE HELPER FUNCTIONS
// ============================================

// Get current month start and end dates
const getCurrentMonth = () => {
    const now = new Date();
    const start = new Date(now.getFullYear(), now.getMonth(), 1);
    const end = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return { start, end };
};

// Get previous month start and end dates
const getPreviousMonth = () => {
    const now = new Date();
    const start = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const end = new Date(now.getFullYear(), now.getMonth(), 0);
    return { start, end };
};

// Get current week start and end dates
const getCurrentWeek = () => {
    const now = new Date();
    const dayOfWeek = now.getDay();
    const start = new Date(now);
    start.setDate(now.getDate() - dayOfWeek);
    start.setHours(0, 0, 0, 0);
    
    const end = new Date(start);
    end.setDate(start.getDate() + 6);
    end.setHours(23, 59, 59, 999);
    
    return { start, end };
};

// Format date to Indonesian format
const formatDate = (date) => {
    return new Date(date).toLocaleDateString('id-ID', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
    });
};

// ============================================
// INSIGHT FUNCTIONS
// ============================================

// Get biggest expense this week
const getBiggestExpenseThisWeek = () => {
    const { start, end } = getCurrentWeek();
    const weekTransactions = getTransactionsByDateRange(start, end)
        .filter(t => t.type === 'expense')
        .sort((a, b) => b.amount - a.amount);
    
    return weekTransactions.length > 0 ? weekTransactions[0] : null;
};

// Get most expensive category
const getMostExpensiveCategory = () => {
    const { start, end } = getCurrentMonth();
    const monthTransactions = getTransactionsByDateRange(start, end);
    const expensesByCategory = getExpenseByCategory(monthTransactions);
    
    if (Object.keys(expensesByCategory).length === 0) return null;
    
    const sorted = Object.entries(expensesByCategory)
        .sort((a, b) => b[1] - a[1]);
    
    return {
        category: sorted[0][0],
        amount: sorted[0][1]
    };
};

// Compare current month vs previous month
const compareMonths = () => {
    const current = getCurrentMonth();
    const previous = getPreviousMonth();
    
    const currentTrans = getTransactionsByDateRange(current.start, current.end);
    const previousTrans = getTransactionsByDateRange(previous.start, previous.end);
    
    const currentTotals = calculateTotals(currentTrans);
    const previousTotals = calculateTotals(previousTrans);
    
    return {
        current: currentTotals,
        previous: previousTotals,
        incomeDiff: currentTotals.income - previousTotals.income,
        expenseDiff: currentTotals.expense - previousTotals.expense,
        incomePercent: previousTotals.income > 0 
            ? ((currentTotals.income - previousTotals.income) / previousTotals.income * 100).toFixed(1)
            : 0,
        expensePercent: previousTotals.expense > 0
            ? ((currentTotals.expense - previousTotals.expense) / previousTotals.expense * 100).toFixed(1)
            : 0
    };
};

// Get budgets near limit
const getBudgetsNearLimit = () => {
    const { start, end } = getCurrentMonth();
    const monthTransactions = getTransactionsByDateRange(start, end);
    const nearLimit = [];
    
    budgets.forEach(budget => {
        let spent = 0;
        
        if (budget.period === 'monthly') {
            spent = monthTransactions
                .filter(t => t.type === 'expense' && t.category === budget.category)
                .reduce((sum, t) => sum + t.amount, 0);
        } else {
            const customTrans = getTransactionsByDateRange(
                new Date(budget.startDate),
                new Date(budget.endDate)
            );
            spent = customTrans
                .filter(t => t.type === 'expense' && t.category === budget.category)
                .reduce((sum, t) => sum + t.amount, 0);
        }
        
        const percentage = budget.amount > 0 ? (spent / budget.amount * 100) : 0;
        
        if (percentage >= 80) {
            nearLimit.push({
                ...budget,
                spent,
                percentage: percentage.toFixed(1)
            });
        }
    });
    
    return nearLimit;
};

// Get average daily spending
const getAverageDailySpending = () => {
    const { start, end } = getCurrentMonth();
    const monthTransactions = getTransactionsByDateRange(start, end)
        .filter(t => t.type === 'expense');
    
    const totalExpense = monthTransactions.reduce((sum, t) => sum + t.amount, 0);
    const daysInMonth = new Date().getDate(); // Days elapsed in current month
    
    return daysInMonth > 0 ? totalExpense / daysInMonth : 0;
};

// ============================================
// TIPS GENERATOR
// ============================================

// Generate personalized tips based on user data
const generateTips = () => {
    const tips = [];
    const { start, end } = getCurrentMonth();
    const monthTransactions = getTransactionsByDateRange(start, end);
    const totals = calculateTotals(monthTransactions);
    const expensesByCategory = getExpenseByCategory(monthTransactions);
    
    // Tip 1: Saving rate
    if (totals.income > 0) {
        const savingRate = ((totals.income - totals.expense) / totals.income * 100).toFixed(1);
        if (savingRate < 20) {
            tips.push({
                icon: '💰',
                title: 'Tingkatkan Tabungan Anda',
                content: `Saat ini Anda menabung ${savingRate}% dari pendapatan. Cobalah untuk menabung minimal 20-30% dari pendapatan bulanan untuk masa depan yang lebih aman.`
            });
        } else {
            tips.push({
                icon: '🎉',
                title: 'Hebat! Tabungan Anda Bagus',
                content: `Anda menabung ${savingRate}% dari pendapatan. Teruskan kebiasaan baik ini dan pertimbangkan untuk investasi jangka panjang.`
            });
        }
    }
    
    // Tip 2: Food expenses
    const foodCategories = ['Makan', 'Jajan', 'Dapur'];
    const foodExpense = foodCategories.reduce((sum, cat) => sum + (expensesByCategory[cat] || 0), 0);
    if (foodExpense > totals.expense * 0.3) {
        tips.push({
            icon: '🍽️',
            title: 'Hemat Pengeluaran Makanan',
            content: `Pengeluaran makanan Anda mencapai ${formatCurrency(foodExpense)}. Coba masak di rumah lebih sering atau bawa bekal untuk menghemat lebih banyak.`
        });
    }
    
    // Tip 3: Budget utilization
    const budgetsNearLimit = getBudgetsNearLimit();
    if (budgetsNearLimit.length > 0) {
        tips.push({
            icon: '⚠️',
            title: 'Perhatikan Budget Anda',
            content: `Beberapa kategori budget hampir habis: ${budgetsNearLimit.map(b => b.category).join(', ')}. Kurangi pengeluaran di kategori tersebut untuk sisa bulan ini.`
        });
    }
    
    // Tip 4: Emergency fund
    if (totals.balance < totals.expense * 3) {
        tips.push({
            icon: '🚨',
            title: 'Bangun Dana Darurat',
            content: 'Dana darurat ideal adalah 3-6 bulan pengeluaran rutin. Mulai sisihkan sebagian pendapatan untuk dana darurat agar lebih siap menghadapi situasi tak terduga.'
        });
    }
    
    // Tip 5: Regular tracking
    tips.push({
        icon: '📊',
        title: 'Catat Setiap Transaksi',
        content: 'Mencatat setiap pemasukan dan pengeluaran membantu Anda lebih sadar akan pola keuangan. Luangkan 5 menit setiap hari untuk update transaksi Anda.'
    });
    
    // Tip 6: 50/30/20 rule
    tips.push({
        icon: '📝',
        title: 'Aturan 50/30/20',
        content: 'Alokasikan 50% pendapatan untuk kebutuhan, 30% untuk keinginan, dan 20% untuk tabungan. Ini adalah formula sederhana untuk mengatur keuangan yang sehat.'
    });
    
    return tips;
};

// ============================================
// NAVIGATION HELPER
// ============================================

// Set active navigation
const setActiveNav = (pageName) => {
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href').includes(pageName)) {
            link.classList.add('active');
        }
    });
};

// ============================================
// ALERT HELPER
// ============================================

// Show alert message
const showAlert = (message, type = 'success') => {
    alert(message);
};

// Confirm dialog
const confirmDialog = (message) => {
    return confirm(message);
};

// ============================================
// INIT ON PAGE LOAD
// ============================================

// Auto-reload data from localStorage when page loads
window.addEventListener('DOMContentLoaded', () => {
    transactions = storage.get('transactions') || [];
    budgets = storage.get('budgets') || [];
    categories = storage.get('categories') || ['Gaji', 'Makan', 'Dapur', 'Jajan', 'Transportasi'];
    profile = storage.get('profile') || {
        name: 'Nama Pengguna',
        email: 'email@example.com',
        photo: '',
        monthlyIncome: 0,
        motto: 'Hemat pangkal kaya'
    };
    
    console.log('Smart Finance loaded successfully!');
    console.log('Transactions:', transactions.length);
    console.log('Budgets:', budgets.length);
    console.log('Categories:', categories.length);
});