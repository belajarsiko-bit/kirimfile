(function () {
  const preloader = document.getElementById('preloader');
  window.addEventListener('load', () => {
    if (preloader) {
      preloader.style.transition = 'opacity 360ms ease';
      preloader.style.opacity = '0';
      setTimeout(() => preloader.remove(), 420);
    }
    revealOnLoad();
  });

  window.addEventListener('scroll', () => {
    const nav = document.querySelector('.navbar');
    if (!nav) return;
    if (window.scrollY > 18) nav.style.boxShadow = '0 10px 30px rgba(0,0,0,0.28)';
    else nav.style.boxShadow = '';
  });

  const filterBtns = Array.from(document.querySelectorAll('.filter-btn'));
  const galleryItems = Array.from(document.querySelectorAll('.gallery-item'));
  if (filterBtns.length && galleryItems.length) {
    filterBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        filterBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const cat = btn.dataset.cat || btn.getAttribute('data-cat') || btn.getAttribute('data-category');
        galleryItems.forEach(item => {
          const itemCat = item.dataset.category;
          item.style.display = (cat === 'all' || itemCat === cat) ? '' : 'none';
        });
      });
    });
  }

  const revealElements = document.querySelectorAll('.reveal');
  const observerOptions = { root: null, rootMargin: '0px', threshold: 0.12 };
  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
        revealObserver.unobserve(entry.target);
      }
    });
  }, observerOptions);

  function revealOnLoad() {
    revealElements.forEach(el => revealObserver.observe(el));
  }

  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    revealOnLoad();
  } else {
    document.addEventListener('DOMContentLoaded', revealOnLoad);
  }

})();
