document.addEventListener('DOMContentLoaded', () => {
    
    // --- 1. NAVBAR STICKY & COLOR CHANGE ---
    const navbar = document.getElementById('navbar');
    
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });

    // --- 2. MOBILE MENU TOGGLE ---
    const hamburger = document.querySelector('.hamburger');
    const navLinks = document.querySelector('.nav-links');
    
    // Buka/Tutup menu saat ikon diklik
    hamburger.addEventListener('click', () => {
        navLinks.classList.toggle('active');
    });

    // Tutup menu saat salah satu link diklik (UX)
    document.querySelectorAll('.nav-links a').forEach(link => {
        link.addEventListener('click', () => {
            navLinks.classList.remove('active');
        });
    });

    // --- 3. SCROLL REVEAL ANIMATION ---
    // Menggunakan Intersection Observer API untuk performa lebih baik
    const revealElements = document.querySelectorAll('.reveal');

    const revealObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('active');
                observer.unobserve(entry.target); // Hanya animasi sekali
            }
        });
    }, {
        root: null,
        threshold: 0.15, // Elemen muncul saat 15% terlihat di layar
        rootMargin: "0px 0px -50px 0px"
    });

    revealElements.forEach(el => {
        revealObserver.observe(el);
    });

    // --- 4. FORM ALERT HANDLING ---
    const form = document.getElementById('bakeryForm');
    
    form.addEventListener('submit', (e) => {
        e.preventDefault(); // Mencegah reload halaman
        
        const nama = document.getElementById('nama').value;
        
        // Tampilkan alert sukses
        alert(`Terima kasih Kak ${nama}! Pesanan/Pesan Anda telah kami terima. Admin kami akan segera menghubungi Anda via WhatsApp/Email.`);
        
        // Reset form jadi kosong lagi
        form.reset();
    });

});