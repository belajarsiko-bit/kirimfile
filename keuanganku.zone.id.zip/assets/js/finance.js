document.addEventListener('DOMContentLoaded', function () {
  const form = document.getElementById('transaction-form');
  const jenisEl = document.getElementById('jenis');
  const tanggalEl = document.getElementById('tanggal');
  const deskripsiEl = document.getElementById('deskripsi');
  const nominalEl = document.getElementById('nominal');

  const totalPemasukanEl = document.getElementById('total-pemasukan');
  const totalPengeluaranEl = document.getElementById('total-pengeluaran');
  const sisaSaldoEl = document.getElementById('sisa-saldo');
  const tbody = document.getElementById('transactions-body');

  if (!form || !jenisEl || !tanggalEl || !deskripsiEl || !nominalEl || !tbody) {
    return;
  }

  const today = new Date().toISOString().slice(0, 10);
  tanggalEl.value = today;

  const transaksi = [];

  const ctx = document.getElementById('financeChart');
  let financeChart = null;

  if (ctx) {
    financeChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['Pemasukan', 'Pengeluaran'],
        datasets: [{
          label: 'Total Bulan Ini (Rp)',
          data: [0, 0],
          borderWidth: 1,
          backgroundColor: [
            'rgba(144, 238, 144, 0.8)',
            'rgba(255, 182, 193, 0.9)'
          ]
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { display: false }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              callback: function (value) {
                return 'Rp ' + value.toLocaleString('id-ID');
              }
            }
          }
        }
      }
    });
  }

  function formatRupiah(value) {
    return 'Rp ' + value.toLocaleString('id-ID');
  }

  function updateSummaryAndChart() {
    let totalPemasukan = 0;
    let totalPengeluaran = 0;

    transaksi.forEach(trx => {
      if (trx.jenis === 'pemasukan') {
        totalPemasukan += trx.nominal;
      } else if (trx.jenis === 'pengeluaran') {
        totalPengeluaran += trx.nominal;
      }
    });

    const saldo = totalPemasukan - totalPengeluaran;

    totalPemasukanEl.textContent = formatRupiah(totalPemasukan);
    totalPengeluaranEl.textContent = formatRupiah(totalPengeluaran);
    sisaSaldoEl.textContent = formatRupiah(saldo);

    if (financeChart) {
      financeChart.data.datasets[0].data = [totalPemasukan, totalPengeluaran];
      financeChart.update();
    }
  }

  function tambahBarisTransaksi(trx) {
    const tr = document.createElement('tr');

    const tanggalTd = document.createElement('td');
    tanggalTd.textContent = trx.tanggalLabel;

    const jenisTd = document.createElement('td');
    jenisTd.textContent = trx.jenis === 'pemasukan' ? 'Pemasukan' : 'Pengeluaran';

    const deskTd = document.createElement('td');
    deskTd.textContent = trx.deskripsi || '-';

    const nominalTd = document.createElement('td');
    nominalTd.textContent = formatRupiah(trx.nominal);

    tr.appendChild(tanggalTd);
    tr.appendChild(jenisTd);
    tr.appendChild(deskTd);
    tr.appendChild(nominalTd);

    tbody.appendChild(tr);
  }

  form.addEventListener('submit', function (e) {
    e.preventDefault();

    const jenis = jenisEl.value;
    const tanggal = tanggalEl.value;
    const deskripsi = deskripsiEl.value.trim();
    const nominal = parseFloat(nominalEl.value);

    if (!tanggal) {
      alert('Tanggal tidak boleh kosong.');
      return;
    }

    if (isNaN(nominal) || nominal <= 0) {
      alert('Nominal harus diisi dengan angka lebih dari 0.');
      return;
    }

    const tanggalObj = new Date(tanggal);
    const tanggalLabel = tanggalObj.toLocaleDateString('id-ID', {
      day: '2-digit',
      month: 'short'
    });

    const trx = {
      jenis,
      tanggal,
      tanggalLabel,
      deskripsi,
      nominal
    };

    transaksi.push(trx);
    tambahBarisTransaksi(trx);
    updateSummaryAndChart();

    deskripsiEl.value = '';
    nominalEl.value = '';
  });
});
