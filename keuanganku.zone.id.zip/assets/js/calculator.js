function hitung(operator) {
  const input1 = document.getElementById('angka1');
  const input2 = document.getElementById('angka2');
  const hasilEl = document.getElementById('hasil');

  if (!input1 || !input2 || !hasilEl) {
    return;
  }

  const angka1 = parseFloat(input1.value);
  const angka2 = parseFloat(input2.value);

  if (isNaN(angka1) || isNaN(angka2)) {
    hasilEl.innerText = 'Masukkan kedua angka';
    return;
  }

  let hasil = 0;

  switch (operator) {
    case '+':
      hasil = angka1 + angka2;
      break;
    case '-':
      hasil = angka1 - angka2;
      break;
    case '*':
      hasil = angka1 * angka2;
      break;
    case '/':
      if (angka2 === 0) {
        hasilEl.innerText = 'Tidak bisa bagi nol';
        return;
      }
      hasil = angka1 / angka2;
      break;
    default:
      return;
  }

  const currencyType = hasilEl.dataset.currency;

  if (currencyType === 'rupiah') {
    hasilEl.innerText = 'Rp ' + hasil.toLocaleString('id-ID', { maximumFractionDigits: 2 });
  } else {
    hasilEl.innerText = hasil.toLocaleString('id-ID');
  }
}
